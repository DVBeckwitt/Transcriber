"""WhisperX transcription launcher package."""
