from __future__ import annotations

import unittest
from unittest.mock import patch

from transcriber.live_wlk import (
    CaptionPair,
    LiveTranslationMode,
    WhisperLiveKitProtocolError,
    _decode_json_message,
    build_wlk_command,
    caption_state_from_full_update,
    is_ready_to_stop,
    resolve_wlk_executable,
    start_wlk_server,
    validate_config_message,
)


class WhisperLiveKitMessageTests(unittest.TestCase):
    def test_parse_config_message_with_pcm_audio_worklet_enabled(self) -> None:
        validate_config_message({"type": "config", "useAudioWorklet": True, "mode": "full"})

    def test_parse_config_message_rejects_encoded_audio_mode(self) -> None:
        with self.assertRaisesRegex(WhisperLiveKitProtocolError, "raw PCM"):
            validate_config_message({"type": "config", "useAudioWorklet": False, "mode": "full"})

    def test_full_update_prefers_translation_and_ignores_silence_lines(self) -> None:
        state = caption_state_from_full_update(
            {
                "status": "active_transcription",
                "lines": [
                    {"speaker": 1, "text": "hola", "translation": "hello"},
                    {"speaker": -2, "text": None},
                    {"speaker": 1, "text": "mundo"},
                ],
                "buffer_translation": "how are",
                "buffer_transcription": "como estan",
                "remaining_time_transcription": 1.25,
            },
            translation_mode=LiveTranslationMode.CASCADE,
        )

        self.assertEqual(state.committed_lines, ("hello", "mundo"))
        self.assertEqual(
            state.committed_pairs,
            (
                CaptionPair(source_text="hola", translated_text="hello"),
                CaptionPair(source_text="mundo", translated_text=""),
            ),
        )
        self.assertEqual(state.partial_line, "how are")
        self.assertEqual(state.lag_seconds, 1.25)

    def test_full_update_keeps_translated_text_when_source_is_missing(self) -> None:
        state = caption_state_from_full_update(
            {
                "lines": [
                    {"speaker": 1, "text": None, "translation": "hello"},
                ],
            },
            translation_mode=LiveTranslationMode.CASCADE,
        )

        self.assertEqual(state.committed_lines, ("hello",))
        self.assertEqual(state.committed_pairs, (CaptionPair(source_text="", translated_text="hello"),))

    def test_full_update_falls_back_to_buffer_transcription(self) -> None:
        state = caption_state_from_full_update(
            {
                "status": "active_transcription",
                "lines": [],
                "buffer_translation": "",
                "buffer_transcription": "partial source",
            },
            translation_mode=LiveTranslationMode.CASCADE,
        )

        self.assertEqual(state.partial_line, "partial source")

    def test_partial_replaces_previous_update_instead_of_appending(self) -> None:
        first = caption_state_from_full_update(
            {"lines": [], "buffer_translation": "hello wor"},
            translation_mode=LiveTranslationMode.DIRECT,
        )
        second = caption_state_from_full_update(
            {"lines": [], "buffer_translation": "hello world"},
            translation_mode=LiveTranslationMode.DIRECT,
        )

        self.assertEqual(first.partial_line, "hello wor")
        self.assertEqual(second.partial_line, "hello world")

    def test_direct_full_update_treats_text_as_english_not_spanish_source(self) -> None:
        state = caption_state_from_full_update(
            {
                "lines": [
                    {"speaker": 1, "text": "Rafa, could you do me a favor, please?", "translation": ""},
                ],
            },
            translation_mode=LiveTranslationMode.DIRECT,
        )

        self.assertEqual(state.committed_lines, ("Rafa, could you do me a favor, please?",))
        self.assertEqual(
            state.committed_pairs,
            (CaptionPair(source_text="", translated_text="Rafa, could you do me a favor, please?"),),
        )

    def test_direct_bad_sample_does_not_write_english_under_spanish(self) -> None:
        state = caption_state_from_full_update(
            {
                "lines": [
                    {"speaker": 1, "text": "Let's hunt the three of us on the beach.", "translation": ""},
                ],
            },
            translation_mode=LiveTranslationMode.DIRECT,
        )

        self.assertEqual(state.committed_lines, ("Let's hunt the three of us on the beach.",))
        self.assertEqual(
            state.committed_pairs,
            (CaptionPair(source_text="", translated_text="Let's hunt the three of us on the beach."),),
        )

    def test_ready_to_stop_is_recognized(self) -> None:
        self.assertTrue(is_ready_to_stop({"type": "ready_to_stop"}))
        self.assertFalse(is_ready_to_stop({"status": "active_transcription"}))

    def test_json_message_decode_rejects_non_object_payload(self) -> None:
        with self.assertRaisesRegex(WhisperLiveKitProtocolError, "JSON object"):
            _decode_json_message("[]")

    def test_resolve_wlk_executable_prefers_wlk(self) -> None:
        def fake_which(executable: str, path: str | None = None) -> str | None:
            if executable == "wlk" and path == "C:/repo/.uv-venv/Scripts":
                return "C:/repo/.uv-venv/Scripts/wlk.exe"
            if executable == "whisperlivekit-server" and path == "C:/repo/.uv-venv/Scripts":
                return "C:/repo/.uv-venv/Scripts/whisperlivekit-server.exe"
            return None

        with (
            patch("transcriber.live_wlk.shutil.which", side_effect=fake_which),
            patch("transcriber.live_wlk.sysconfig.get_path", return_value="C:/repo/.uv-venv/Scripts"),
            patch("transcriber.live_wlk.sys.executable", "C:/repo/.uv-venv/Scripts/python.exe"),
        ):
            self.assertEqual(resolve_wlk_executable(), "C:/repo/.uv-venv/Scripts/wlk.exe")

    def test_resolve_wlk_executable_prefers_active_python_scripts_directory_over_path(self) -> None:
        def fake_which(executable: str, path: str | None = None) -> str | None:
            if executable == "wlk" and path == "C:/repo/.uv-venv/Scripts":
                return "C:/repo/.uv-venv/Scripts/wlk.exe"
            if executable == "wlk" and path is None:
                return "C:/global/wlk.exe"
            return None

        with (
            patch("transcriber.live_wlk.shutil.which", side_effect=fake_which),
            patch("transcriber.live_wlk.sysconfig.get_path", return_value="C:/repo/.uv-venv/Scripts"),
            patch("transcriber.live_wlk.sys.executable", "C:/repo/.uv-venv/Scripts/python.exe"),
        ):
            self.assertEqual(resolve_wlk_executable(), "C:/repo/.uv-venv/Scripts/wlk.exe")

    def test_start_wlk_server_terminates_process_when_health_check_fails(self) -> None:
        class FakeProcess:
            terminated = False

            def poll(self) -> None:
                return None

            def terminate(self) -> None:
                self.terminated = True

            def wait(self, timeout: float) -> None:
                return None

        process = FakeProcess()

        with (
            patch("transcriber.live_wlk.resolve_wlk_executable", return_value="wlk"),
            patch("transcriber.live_wlk.subprocess.Popen", return_value=process),
            patch("transcriber.live_wlk.wait_for_wlk_health", side_effect=RuntimeError("not ready")),
        ):
            with self.assertRaisesRegex(RuntimeError, "not ready"):
                start_wlk_server(
                    host="127.0.0.1",
                    port=8123,
                    model="small",
                    language="es",
                    asr_prompt=None,
                    translation_mode=LiveTranslationMode.DIRECT,
                )

        self.assertTrue(process.terminated)

    def test_build_wlk_command_uses_direct_translation_without_diarization(self) -> None:
        command = build_wlk_command(
            "wlk",
            host="127.0.0.1",
            port=8123,
            model="small",
            language="es",
            asr_prompt="OpenAI Codex",
            static_prompt="Keep glossary stable",
            translation_mode=LiveTranslationMode.DIRECT,
            backend="auto",
            backend_policy="localagreement",
            frame_threshold=25,
            beams=1,
            decoder="auto",
            audio_min_len=0.0,
            audio_max_len=30.0,
            nllb_backend="transformers",
            nllb_size="600M",
        )

        self.assertEqual(command[:2], ["wlk", "--host"])
        self.assertIn("--pcm-input", command)
        self.assertIn("--direct-english-translation", command)
        self.assertNotIn("--target-language", command)
        self.assertIn("--backend-policy", command)
        self.assertIn("localagreement", command)
        self.assertNotIn("simulstreaming", command)
        self.assertNotIn("--beams", command)
        self.assertIn("--init-prompt", command)
        self.assertIn("--static-init-prompt", command)
        self.assertNotIn("--diarization", command)

    def test_build_wlk_command_uses_cascade_target_language_without_direct_translation(self) -> None:
        command = build_wlk_command(
            "wlk",
            host="127.0.0.1",
            port=8123,
            model="small",
            language="es",
            asr_prompt=None,
            translation_mode=LiveTranslationMode.CASCADE,
            static_prompt=None,
            backend="faster-whisper",
            backend_policy="localagreement",
            frame_threshold=35,
            beams=3,
            decoder="beam",
            audio_min_len=1.0,
            audio_max_len=45.0,
            nllb_backend="ctranslate2",
            nllb_size="600M",
        )

        self.assertIn("--pcm-input", command)
        self.assertIn("--target-language", command)
        self.assertIn("en", command)
        self.assertNotIn("--direct-english-translation", command)
        self.assertNotIn("--diarization", command)
        self.assertIn("--backend", command)
        self.assertIn("faster-whisper", command)
        self.assertIn("--frame-threshold", command)
        self.assertIn("35", command)
        self.assertIn("--beams", command)
        self.assertIn("3", command)
        self.assertIn("--decoder", command)
        self.assertIn("beam", command)
        self.assertIn("--audio-min-len", command)
        self.assertIn("1.0", command)
        self.assertIn("--audio-max-len", command)
        self.assertIn("45.0", command)
        self.assertIn("--nllb-backend", command)
        self.assertIn("ctranslate2", command)


if __name__ == "__main__":
    unittest.main()
