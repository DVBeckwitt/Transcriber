"""WhisperX transcription launcher package."""

